package com.Berliana.PBO.pertemuan4;

public class main {

    public static void main(String[] args) {

        manajer manajer = new manajer();
        manajer.nip = 123;
        manajer.nama = "Berliana";

        manajer.showInfo();

        manajer.bonus(10000);

    }
}
