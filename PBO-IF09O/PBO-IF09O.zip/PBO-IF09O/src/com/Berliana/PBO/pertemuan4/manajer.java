package com.Berliana.PBO.pertemuan4;

public class manajer extends Pegawai {

    public void bonus(int bonus){
        System.out.println("Pegawai dengan nama : " + nama + "Dengan NIP : " + nip);
    }
}
