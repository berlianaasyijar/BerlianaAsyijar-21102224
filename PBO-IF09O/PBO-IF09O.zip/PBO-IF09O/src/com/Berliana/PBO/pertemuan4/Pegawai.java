package com.Berliana.PBO.pertemuan4;

public class Pegawai {

    //Atributs
    String nama;
    int nip;

    public void showInfo() {
        System.out.println("Nama : " + nama);
        System.out.println("NIP : " + nip);
    }
}
