package com.Berliana.PBO.pertemuan2;

public class variabels {

    public static void main(String[] args)  {

        String nama = "Berliana Asyijar";
        int umur = 19;


        System.out.println("Nama Saya : " + nama);
        System.out.println("Umur Saya : " +umur);
    }
}
